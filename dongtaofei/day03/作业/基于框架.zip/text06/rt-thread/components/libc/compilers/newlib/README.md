# NEWLIB (GCC) porting for RT-Thread

https://sourceware.org/newlib/libc.html#Reentrancy

